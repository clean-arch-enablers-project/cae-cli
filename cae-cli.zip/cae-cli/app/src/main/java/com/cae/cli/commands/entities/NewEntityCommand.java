package com.cae.cli.commands.entities;

public class NewEntityCommand {
}
